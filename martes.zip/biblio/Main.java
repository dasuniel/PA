import java.util.Scanner;


class Main{
  public static void main(String[] args){
    Libro unLibro = new Libro;

    
    String autor;
    boolean estaPrestado;
    String ISBN;
    String titulo;
    int anioPublicacion;


    Biblioteca laBiblioteca = new Biblioteca;
    
    int menu;
    Scanner sc = new Scanner(System.ln);
    switch( menu ){
        system.out.println("Que quiere hacer: ");
        system.out.println("\n1.Prestar Libro: ");
        system.out.println("\2.nAdicionar Libro: ");
        system.out.println("\n3.Devolver Libro: ");
        system.out.println("\n4.Mostrar Libros: ");
        system.out.println("\n5.Fin. ");
        menu = sc.nextInt();

        
      case 1:{
      system.out.println(" ");
        
      }
      case 2:{
      system.out.println("Detalles de Libro: ");

        system.out.println("Autor: ");
        autor = sc.nextLine();
        unLibro.autor = autor;
        
        unLibro.estaPrestado = False;
        
        system.out.println("ISBN: ");
        ISBN = sc.nextLine();
        unLibro.ISBN = ISBN;
        
        system.out.println("Titulo: ");
        titulo = sc.nextLine();
        unLibro.titulo = titulo;
        
        system.out.println("Anio Publicacion: ");
        anioPublicacion = sc.nextInt();
        unLibro.anioPublicacion = anioPublicacion;

        laBiblioteca.listaLibros[] = unLibro;
          }
        case 3:{
      system.out.println(" ");
        
      }
        case 4:{
      system.out.println(" ");
        
      }
        case 5:{
      system.out.println(" ");
        break;
      }
    }

  for (int i )



    
  }
  
}