class Biblioteca{
  Libro[] listaLibros = new Libro[50];
  
}