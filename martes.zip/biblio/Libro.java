class Libro{
  String autor;
  boolean estaPrestado;
  String ISBN;
  String titulo;
  int anioPublicacion;
}